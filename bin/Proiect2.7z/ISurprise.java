
public interface ISurprise {

	void enjoy();
}
